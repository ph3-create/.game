var config = {
    type: Phaser.AUTO,
    width: Math.min(window.innerWidth, window.outerWidth),
    height: Math.min(window.innerHeight, window.outerHeight),
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },    
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    debug: true
};

var game = new Phaser.Game(config);

var backgroundLayer;
var collisionLayer;
var itemsLayer;

var map;
var coinsCollected = 0;
var bestCollected = 0;
var text;
var player;
var items;
var bombs = [];
var gameOver = false;
var move_ctl = false;
var left,right,up,down;
var numberOfBombs = 10;
var gameoversound;
var itemsound;
var bgMusic;
var extracoins;
var isCollision;
var bombSpeed=70;
var normalplayerspeed=150;
var boostedplayerspeed=225;
var playerspeed=normalplayerspeed;
var timer;

var timedEvent;

function preload (){
    this.load.spritesheet('robot', 'assets/lego.png',
        { frameWidth: 37, frameHeight: 48 } ); 

    this.load.spritesheet('items', 'assets/items.png', { frameWidth: 32, frameHeight: 32 } ); 
    
    this.load.spritesheet('bombs', 'assets/bomb.png', { frameWidth: 32, frameHeight: 32 } ); 

    this.load.image('tiles', 'assets/map_tiles.png');
    this.load.tilemapTiledJSON('json_map', 'assets/json_map.json');
    
    this.load.audio('gameover', ['assets/sounds/gameover.ogg', 'assets/sounds/gameover.mp3']);
    this.load.audio('pickupitem', ['assets/sounds/pickupitem.ogg', 'assets/sounds/pickupitem.mp3']);
    this.load.audio('bgsound', ['assets/sounds/bgsound.ogg', 'assets/sounds/bgsound.mp3']);
    this.load.audio('extracoins', ['assets/sounds/extracoins.ogg', 'assets/sounds/extracoins.mp3']);
}

function resize (width, height){
/*    if (width === undefined) { width = game.config.width; }
    if (height === undefined) { height = game.config.height; }
    //console.log('W: ' +  width + ', H: ' + height); 
    if (width < backgroundLayer.width || height < backgroundLayer.height) {
		map.scene.cameras.main.zoom = 0.5;
		map.scene.cameras.main.setPosition(-width/2, -height/2);
  } else {
		map.scene.cameras.main.zoom = 1;
		map.scene.cameras.main.setPosition(0,0);
	}
    //backgroundLayer.setSize(width, height);
    map.scene.cameras.resize(width/map.scene.cameras.main.zoom, height/map.scene.cameras.main.zoom);
	if (game.renderer.type === Phaser.WEBGL){	
		game.renderer.resize(width, height);
	}
    updateText();
*/
}		

function create ()
{
    bestCollected = localStorage.getItem(0);
    if(bestCollected === null)
        bestCollected = 0;
    
    isCollision = 0;
    map = this.make.tilemap({ key: 'json_map' });
    //F: 'map_tiles' - name of the tilesets in json_map.json
    //F: 'tiles' - name of the image in load.images()
    var tiles = map.addTilesetImage('map_tiles','tiles');

    backgroundLayer = map.createDynamicLayer('background', tiles, 0, 0);
    collisionLayer = map.createDynamicLayer('collision', tiles, 0, 0);//.setVisible(false);
    collisionLayer.setCollisionByExclusion([ -1 ]);
    
    map.scene.cameras.main.backgroundColor = Phaser.Display.Color.HexStringToColor("#aaff7f");
    
    items = this.physics.add.sprite(600, 200, 'items', 0);      
    items.setBounce(0.1);
    
    player = this.physics.add.sprite(650, 300, 'robot');
    player.setBounce(0.1);
    
    this.physics.add.collider(player, collisionLayer);
    this.physics.add.overlap(player, backgroundLayer);
    
    //F:set collision range 
    backgroundLayer.setCollisionBetween(1, 25);    
       
    //F:Checks to see if the player overlaps with any of the items, 
    //f:if he does call the collisionHandler function
    this.physics.add.overlap(player, items, collisionHandler);
    
    this.cameras.main.startFollow(player);    
    
    //add bombs
    for(var i=0;i<numberOfBombs;i++)
    {
        bombs[i] = this.physics.add.sprite(0, 0, 'bombs');
        this.physics.add.overlap(player, bombs[i], bombGotMe);
        bombs[i].disableBody(true, true);
    }
    
    text = this.add.text(game.canvas.width/2, 16, '', {
        fontSize: '3em',
        fontFamily: 'fantasy',
        align: 'center',
        boundsAlignH: "center", 
        boundsAlignV: "top", 
        fill: '#ffffff'
    });
    text.setOrigin(0.5);
    text.setScrollFactor(0);    
    updateText();
    
    this.anims.create({
        key: 'run',
        frames: this.anims.generateFrameNumbers('robot', { start: 0, end: 16 }),
        frameRate: 20,
        repeat: -1
    }); 
    
    cursors = this.input.keyboard.createCursorKeys();  

    this.input.on('pointerdown', function (pointer) { 
            move_ctl = true; 
            pointer_move(pointer); 
    });
    this.input.on('pointerup', function (pointer) { move_ctl = false; reset_move()});
    this.input.on('pointermove', pointer_move);
    window.addEventListener('resize', function (event) {
            resize(Math.min(window.innerWidth, window.outerWidth), Math.min(window.innerHeight, window.outerHeight));
    }, false);		
    resize(Math.min(window.innerWidth, window.outerWidth), Math.min(window.innerHeight, window.outerHeight));
        
    timedEvent = this.time.addEvent({ delay: 10000, callback: timeOut, callbackScope: this, repeat: 999 });
    timedEvent.paused = true;
    
    timer = this.time.addEvent({ delay: 1000, callback: timerEvent, callbackScope: this, loop: true });
    timer.paused = true;
    
    gameoversound = this.sound.add('gameover');
    itemsound = this.sound.add('pickupitem');
    bgMusic = this.sound.add('bgsound', {volume: 0.3, loop: true});
    extracoins = this.sound.add('extracoins');
    
    bgMusic.play();
    var context = new AudioContext();
    context.resume();
    
}

function timerEvent()
{
    playerspeed = normalplayerspeed;
}

function timeOut(){
    if(coinsCollected > 0)
    {
        coinsCollected--;
        updateText();
    }
}

function pointer_move(pointer) {
		var dx=dy=0;
		//var min_pointer=20; // virtual joystick
		var min_pointer = (player.body.width + player.body.height) / 4 ; // following pointer by player
		if (move_ctl) {
			reset_move();
/*			// virtual joystick
 			dx =  (pointer.x - pointer.downX); 
			dy = (pointer.y - pointer.downY);*/
			
			// following pointer by player
			dx = (pointer.x / map.scene.cameras.main.zoom - player.x);
			dy = (pointer.y / map.scene.cameras.main.zoom - player.y);
		    //console.log( 'Xp:'  + player.x + ', Xc:'  + pointer.x + ', Yp:' + player.y + ', Yc:' + pointer.y );
			
			if (Math.abs(dx) > min_pointer) {
				left = (dx < 0); 
				right = !left; 
			} else { 
				left = right = false;
			}
			if (Math.abs(dy) > min_pointer) {
				up = (dy < 0); 
				down = !up; 
			} else { 
				up = down = false;
			}
		}
		//console.log( 'L:'  + left + ', R:'  + right + ', U:' + up + ', D:' + down, ', dx: ' + dx + ',dy: ' + dy );
}

function reset_move() {
  up = down = left = right = false;
}

function update (){     
    // Needed for player following the pointer:
    if (move_ctl) { pointer_move(game.input.activePointer); }
	
    // Horizontal movement
    if (cursors.left.isDown || left)
    {
        player.body.setVelocityX(-playerspeed);
        player.angle = 90;
        player.anims.play('run', true); 
    }
    else if (cursors.right.isDown || right)
    {
        player.body.setVelocityX(playerspeed);
        player.angle = 270;
        player.anims.play('run', true); 
    }
    else
    {
        player.body.setVelocityX(0);
    }

    // Vertical movement
    if (cursors.up.isDown || up)
    {
        player.body.setVelocityY(-playerspeed);
        player.angle = 180;
        player.anims.play('run', true); 
    }
    else if (cursors.down.isDown || down)
    {
        player.body.setVelocityY(playerspeed);
        player.anims.play('run', true); 
        player.angle = 0;
    }
    else
    {
        player.body.setVelocityY(0);
    }

    if(cursors.up.isUp && cursors.down.isUp && cursors.left.isUp && cursors.right.isUp)
        player.anims.play('run', false);
    
    for(var i=0;i<numberOfBombs;i++)
    {
        followMe(bombs[i], bombSpeed + (i*15));
        if(coinsCollected > 10 * i + 5)
            enableBomb(bombs[i]);
    }

}

function bombGotMe()
{
    coinsCollected=0;
    updateText();
    gameoversound.play();
    for(var i=0;i<numberOfBombs;i++)
    {
        bombs[i].disableBody(true, true);
    }
}

function followMe(bomb, speed)
{
    if (bomb.body.enable === true)
    {
        var x = player.x - bomb.x;
        var y = player.y - bomb.y;

        if(speed > 130)
            speed = 130;
        bomb.body.setVelocityX(x > 0 ? speed : -speed);
        bomb.body.setVelocityY(y > 0 ? speed : -speed);
    }
}

function enableBomb(bomb)
{
    if (bomb.body.enable === false)
        bomb.enableBody(true, -10, -10, true, true);
}

function updateText (){
	text.setPosition(game.canvas.width/2 / map.scene.cameras.main.zoom, text.height+16);
    text.setText(
        'Coins collected: ' + coinsCollected + '    Best result: ' + bestCollected
    );
    text.setColor('white');
}

// If the player collides with items
function collisionHandler (player, item) { 
    
    if(items.frame.name >= 7 && items.frame.name <= 11)
    {
        extracoins.play();
        coinsCollected += 5;
    }
    else
    {
        itemsound.play();
        coinsCollected += 1;
        if (item.frame.name >= 77 && items.frame.name <= 118)
        {
            timer.elapsed = 0;
            if(timer.paused)
                timer.paused = false;
            playerspeed = boostedplayerspeed;
        }
    }
    
    if (coinsCollected > bestCollected)
    {
        bestCollected = coinsCollected;
        localStorage.setItem(0, bestCollected);
    }
    updateText();
    //items.destroy();  
    item.disableBody(true, true);

    if (item.body.enable == false)
    {
        var h = map.heightInPixels-40;
        var w = map.widthInPixels-40;
        var itemX = Phaser.Math.Between(40, w);
        var itemY = Phaser.Math.Between(40, h);
        
        var itemID = Phaser.Math.Between(0, 118);
        item.setFrame(itemID);
        item.enableBody(true, itemX, itemY, true, true);

        timedEvent.elapsed = 0;
        if(timedEvent.paused)
            timedEvent.paused = false;
    }
       
}

